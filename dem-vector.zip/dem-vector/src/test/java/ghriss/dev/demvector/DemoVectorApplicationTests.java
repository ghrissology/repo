package ghriss.dev.demvector;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoVectorApplicationTests {

	@Test
	void contextLoads() {
	}

}
