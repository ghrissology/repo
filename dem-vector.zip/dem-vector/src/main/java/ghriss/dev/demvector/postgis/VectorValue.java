package ghriss.dev.demvector.postgis;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.locationtech.jts.geom.LineString;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Entity
@Getter
@Setter
@ToString
@Table(name = "vector_value")
public class VectorValue {

    @Id
    Long id;
    Timestamp timeStamp;
    BigDecimal index;
    BigDecimal value;
    LineString data;
}
