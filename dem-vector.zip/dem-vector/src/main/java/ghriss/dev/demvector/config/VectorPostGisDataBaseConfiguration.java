package ghriss.dev.demvector.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateProperties;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateSettings;
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.Map;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        basePackages = "ghriss.dev.demvector.postgis",
        entityManagerFactoryRef = "postGisEntityManagerFactory",
        transactionManagerRef = "postGisTransactionManager")
public class VectorPostGisDataBaseConfiguration {

    @Autowired
    private JpaProperties jpaProperties;
    @Autowired
    private HibernateProperties hibernateProperties;

    private Map<String, Object> getVendorProperties() {
        return hibernateProperties.determineHibernateProperties(jpaProperties.getProperties(), new HibernateSettings());
    }

    @Primary
    @Bean(name = "postGisDataSource")
    @ConfigurationProperties(prefix="spring.datasource.postgis")
    public DataSource postGisDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Primary
    @Bean(name = "postGisEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean postGisEntityManager(
            EntityManagerFactoryBuilder builder,
            @Qualifier("postGisDataSource") DataSource dataSource
    ) {
        return builder
                .dataSource(dataSource)
                .packages("ghriss.dev.demvector.postgis")
                .persistenceUnit("postGis_db")
                .properties(getVendorProperties())
                .build();
    }



    @Primary
    @Bean(name = "postGisTransactionManager")
    public PlatformTransactionManager postGisTransactionManager(
            @Qualifier("postGisEntityManagerFactory") EntityManagerFactory postGisEntityManagerFactory
    ) {
        return new JpaTransactionManager(postGisEntityManagerFactory);
    }
}
