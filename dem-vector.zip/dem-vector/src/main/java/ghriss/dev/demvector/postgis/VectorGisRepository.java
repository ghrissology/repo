package ghriss.dev.demvector.postgis;


import org.springframework.data.jpa.repository.JpaRepository;

public interface VectorGisRepository extends JpaRepository<VectorValue, String> {

}
