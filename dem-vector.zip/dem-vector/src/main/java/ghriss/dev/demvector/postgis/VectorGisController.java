package ghriss.dev.demvector.postgis;

import lombok.AllArgsConstructor;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.geom.LineString;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.util.HashSet;
import java.util.Set;

@RestController
@AllArgsConstructor
@RequestMapping("/")
public class VectorGisController {

    private final VectorGisRepository vectorGisRepository;

    @GetMapping("/start")
    public void testApp(){
        System.out.println("hi there....");
    }
    @GetMapping("/testGis")
    public String test(){
        VectorValue vectorValue = new VectorValue();
        vectorValue.setId(1L);
        vectorValue.setTimeStamp(Timestamp.from(Instant.now()));
        vectorValue.setIndex(BigDecimal.valueOf(1));
        vectorValue.setValue(BigDecimal.valueOf(2));
        GeometryFactory geometryFactory = new GeometryFactory();

        Set<Coordinate> coordinates = new HashSet<>();
        for (int i = 0; i < 1000; i++) {
            coordinates.add(new Coordinate(Math.random(),Math.random()));
        }
        LineString linearRing = geometryFactory.createLineString(coordinates.toArray(new Coordinate[1000]));
        vectorValue.setData(linearRing);
        Instant start = Instant.now();
        VectorValue save = vectorGisRepository.save(vectorValue);
        Instant end = Instant.now();
        System.out.println("Save in SIG : " + Duration.between(start, end).getNano()/1000000 +" ms");
        return save.toString();
    }
}
